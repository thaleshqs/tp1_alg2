#ifndef TRIE_HPP
#define TRIE_HPP
#include <iostream>
using namespace std;

class Trie {
public:
	Trie();
	bool isEmpty();
    void insert(string, int &);
    int search(const string &);
	bool erase(string, Trie* &, Trie* &);
	void freeNodes(Trie*);

private:	
    int id;
	int size;
    bool isLeaf;
    Trie *child[constants::SIZE];
};

#endif