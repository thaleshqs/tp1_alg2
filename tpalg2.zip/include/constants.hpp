#ifndef CONSTANTS_HPP
#define CONSTANTS_HPP

//constantes referentes ao tamanho do alfabeto
//e numero do primeiro caracter
namespace constants {
	constexpr int SIZE{95};
	constexpr int FIRST{32};
}

#endif