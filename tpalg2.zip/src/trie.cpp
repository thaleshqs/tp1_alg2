#include "constants.hpp"
#include "trie.hpp"

//construtor
Trie::Trie() {
	this->isLeaf = false;
	this->size = 0;
	for (size_t i = 0;i < constants::SIZE;i++) {
		this->child[i] = NULL;
	}	
}

//arvore esta vazia?
bool Trie::isEmpty() {
	return this->size == 0;
}

//insercao
void Trie::insert(string str, int & nodeCount) {
    Trie* aux = this;
	//percorre a trie seguindo os simbolos da chave
    for (size_t i = 0;i < str.length();i++) {
        if (aux->child[str[i] - constants::FIRST] == NULL) 
            aux->child[str[i] - constants::FIRST] = new Trie();
        aux = aux->child[str[i] - constants::FIRST];
    }
    
	//atualiza variaveis
    aux->id = nodeCount++;
	this->size++;
    aux->isLeaf = true;
}

//retorna índice da chave, se for encontrada. 
//Senao, retorna 0
int Trie::search(const string & str) {
    if (this->isEmpty())
        return 0;
    
    Trie* aux = this;
    for (size_t i = 0;i < str.length();i++) {
        aux = aux->child[str[i] - constants::FIRST];
        
        if (aux == NULL)
            return 0;
    }
    
    if (aux->isLeaf)
        return aux->id;
    else
        return 0;
}

//remover
bool Trie::erase(string str, Trie* & node, Trie* & head) {
	if (node == nullptr)
		return false;
	
	//chave nao vazia
	if (str.length() != 0) {
		if (node != nullptr
		&&  node->child[str[0] - constants::FIRST] != nullptr
		&&  erase(str.substr(1), node->child[str[0] - constants::FIRST], head)
		&&	node->isLeaf == false) {
			//testa se no tem filho
			bool hasChildren = false;
			for (int i = 0;i < constants::SIZE;i++) {
				if (node->child[i]) {
					hasChildren = true;
					break;
				}
			}
			
			head->size--;
			if (hasChildren) { //no com filhos
				return false;
			} else { //no sem filhos
				delete node;
				node = nullptr;
				return true;
			}
			
		}
	}
	
	//chave vazia e no folha
	if (str.length() == 0 && node->isLeaf) {
		//testa se tem filhos
		bool hasChildren = false;
		for (int i = 0;i < constants::SIZE;i++) {
			if (node->child[i]) {
				hasChildren = true;
				break;
			}
		}
		
		head->size--;
		if (hasChildren) { //no com filhos
			node->isLeaf = false;
			return false;
		} else { //no sem filhos
			delete node;
			node = nullptr;
			return true;
		}
	}

	return false;
}

//liberar memoria
void Trie::freeNodes(Trie* aux) {
	for (int i = 0;i < constants::SIZE;i++) {
		if (aux->child[i] != NULL)
			freeNodes(aux->child[i]);
	}
	
	delete aux;
}