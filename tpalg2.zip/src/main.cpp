/*
	DCC207 - Algoritmos 2
	Trabalho Pratico I -- Manipulacao de sequencias
	Thales Henrique Silva
	2020007040
*/
#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include "constants.hpp"
#include "trie.hpp"

using namespace std;

//converter decimal para binario
string decToBin(int, int);

//converter binario para decimal
int binToDec(const string &);

int main(int argc, char** argv) {
	string arg1 = argv[1];
	if (arg1 == "-c") { //compressao
		//arquivos de entrada e saida
		ifstream input(argv[2]);
		ofstream output;
		
		//define nome do arquivo de saida
		if (argc == 3) {
			string newName = "";
			string arg = argv[2];
			for (size_t i = 0;i < arg.length() - 3;i++) newName += arg[i];
			newName += "z78";
			output.open(newName);
		} else {
			output.open(argv[4]);
		}
		
		//construcao da trie
		int nodeCount = 1; //numero de palavras inseridas
		Trie* tree = new Trie();
		tree->insert("", nodeCount);
		
		//leitura do arquivo
		bool firstLine = true;
		while (input) {
			//linha do arquivo
			string str;
			getline(input, str);
			
			//algoritmo de compressao
			string compressed = "";
			size_t i = 0;
			while (i < str.length()) {
				if (str.length() > 0 && (str[0] == '\r' || str[0] == '\n')) break;
				//o loop abaixo percorre a trie  
				//ate achar uma string nova
				string aux = "";
				int index = 0;
				int searchResult = tree->search(aux);
				while (i < str.length() &&  searchResult != 0) {
				   if (str[i] == '\t' || str[i] == '\r') {
					   i++;
					   continue;
				   }
				   
				   //se um caracter nao for da tabela ASCII padrao
				   //ele sera substituido por um "?"
				   if (str[i] < constants::FIRST || str[i] > constants::FIRST + constants::SIZE) {
					   aux += "?";
					   index = searchResult;
					   i++;
					   searchResult = tree->search(aux);
					   continue;
				   }
				   aux += str[i];
				   index = searchResult;
				   i++;
				   searchResult = tree->search(aux);
				}
				
				//b se refere ao numero de bits 
				//para indexar o indice da string
				int b;
				if (nodeCount == 2)
					b = 1; //caso especial na 1a insercao
				else
					b = ceil(log2(nodeCount - 1)); //o teto do logaritmo indica o numero de bits
				
				//adiciona-se o indice em binario
				compressed += decToBin(index - 1, b);
				
				//adiciona-se o binario referente ao
				//ultimo caracter na string 
				if (aux.length() > 0) {
					char c = aux[aux.length() - 1];
					int x = c;
					compressed += decToBin(x, 8);
				}
				
				//insere a nova string na trie
				tree->insert(aux, nodeCount);
			}
			
			//adiciona o resultado a saida
			if (firstLine) {
				output << compressed;
				firstLine = false;
			} else {
				output << "\n" << compressed;
			}
			
		}
		
		//libera memoria
		tree->freeNodes(tree);
	} else { //descompressao
		//abertura dos arquivos
		ifstream input(argv[2]);
		ofstream output;
		if (argc == 3) {
			string newName = "";
			string arg = argv[2];
			for (size_t i = 0;i < arg.length() - 3;i++) newName += string(1, arg[i]);
			newName += "txt";
			output.open(newName);
		} else {
			output.open(argv[4]);
		}		
		
		//criacao da string
		//e do dicionario
		vector<string> dict;
		dict.push_back("");
		int curr = 1; //numero de bits atual do indice
		int dictSize = 1; //tamanho do dicionario
		bool firstLine = true;
		while (input) {
			string myLine;
			getline(input, myLine);
			//decompressed = myLine;
			string decompressed = "";	
			
			//algoritmo de descompressao
			size_t i = 0;
			while (i < myLine.length()) {
				//curr = numero de bits para indexar
				//a entrada no dicionario
				//a logica e a mesma da compressao
				if (dictSize <= 1 )
					curr = 1;
				else
					curr = ceil(log2(dictSize));
				
				//indice em binario
				string binIndex = "";
				int j = 0;
				while (j < curr) {
					binIndex = binIndex + myLine[i];
					j++, i++;
				}
				
				//8 bits referentes ao caracter
				string character = "";
				j = 0;
				while (j < 8) {
					character += myLine[i];
					i++, j++;
				}
				
				//transforma o binario em decimal
				//e recupera o char correspondente
				string x(1, char(binToDec(character)));
				
				//insercao no dicionario
				dict.push_back(dict[binToDec(binIndex)] + x);
				
				//concatenacao
				decompressed += dict[binToDec(binIndex)] + x;
				dictSize++;
			}
			if (firstLine) {
				output << decompressed;
				firstLine = false;
			} else {
				output << "\n" << decompressed;
			}
			
		}
    }

    return 0;
}

//implementacoes auxiliares

string decToBin(int n, int b) {
    string res = string(b, '0');
    int i = b - 1;
    while (n > 0) {
        char c = '0' + (n % 2);
        res[i] = c;
        n = n / 2;
        i--;
    }
	
    return res;
}

int binToDec(const string & str) {
    int sum = 0, aux = 1;
    for (int i = str.length() - 1; i >= 0;i--) {
        if (str[i] == '1')
            sum += aux;
        aux *= 2;
    }
    
    return sum;
}